# Real-Time Object Detection Using the YOLOv7 Algorithm

A Streamlit project starter for an academic demonstration. It supports image detection, video processing, and camera snapshots using a local YOLOv7 model.

## 1. Project structure

```text
yolov7_object_detection_project/
├── app.py
├── requirements.txt
├── README.md
├── yolov7/          # Clone the official YOLOv7 repository here
└── weights/
    └── yolov7.pt    # Place compatible model weights here
```

## 2. Setup

Use a Python environment compatible with the official YOLOv7 repository and its PyTorch dependencies.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
git clone https://github.com/WongKinYiu/yolov7.git
cd yolov7
pip install -r requirements.txt
cd ..
```

Download or copy a compatible YOLOv7 `.pt` checkpoint into `weights/yolov7.pt`. The checkpoint is not included in this starter project. Use weights you are permitted to use and check their license and intended dataset.

## 3. Run the app

From the project folder:

```bash
streamlit run app.py
```

If your folders differ, change **Weights file** and **YOLOv7 repository folder** in the sidebar.

## 4. Deploying on Streamlit Community Cloud

The official YOLOv7 repository and its dependencies can be challenging to deploy on a hosted service because of PyTorch version, Python version, disk, and memory constraints. For deployment, test locally first and use a compatible Python runtime. Do not assume the hosted environment will have GPU access. Keep large model weights out of Git if they exceed hosting limits; use an approved model storage method and configure the app to download or access them securely.

## 5. Features

- Image upload with annotated detection output
- Detection table with class, confidence, and bounding-box coordinates
- CSV download for image detections
- Video upload and frame-by-frame annotated video output
- Camera snapshot detection
- Confidence and NMS IoU sliders
- Project overview and model information

## 6. Notes

- This is an app scaffold, not a claim of measured project performance.
- The app requires the official YOLOv7 repository and a compatible checkpoint.
- `st.camera_input` captures a snapshot; continuous real-time webcam processing needs a streaming implementation such as `streamlit-webrtc`.
- Record FPS, precision, recall, and mAP only after testing on your actual hardware and dataset.
