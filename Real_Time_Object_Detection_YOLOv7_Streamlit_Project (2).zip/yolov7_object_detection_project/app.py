import streamlit as st
from pathlib import Path
import tempfile
import time
import cv2
import numpy as np
from PIL import Image

st.set_page_config(
    page_title="Real-Time Object Detection | YOLOv7",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .stApp { background: #f4f7fb; }
    [data-testid="stSidebar"] { background: linear-gradient(180deg,#102b4e,#173c67); }
    [data-testid="stSidebar"] * { color: #ffffff !important; }
    .hero {
        padding: 1.25rem 1.5rem; border-radius: 16px; color: white;
        background: linear-gradient(110deg,#102b4e,#1769aa);
        margin-bottom: 1rem;
    }
    .hero h1 { margin: 0; font-size: 2rem; }
    .hero p { margin: .4rem 0 0 0; opacity: .9; }
    .metric-card {
        padding: 1rem; border-radius: 12px; background: white;
        border: 1px solid #e2e8f0; min-height: 95px;
    }
    .metric-label { color: #64748b; font-size: .9rem; }
    .metric-value { color: #0f2f54; font-size: 1.5rem; font-weight: 700; }
    .section-card {
        padding: 1rem; background: white; border: 1px solid #e2e8f0;
        border-radius: 14px; margin-bottom: 1rem;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_resource(show_spinner=False)
def load_model(weights_path: str, repo_path: str, conf: float, iou: float):
    """Load a local YOLOv7 model. Requires a cloned YOLOv7 repo and compatible weights."""
    import torch
    model = torch.hub.load(
        repo_path,
        "custom",
        path=weights_path,
        source="local",
        force_reload=False,
    )
    model.conf = conf
    model.iou = iou
    return model

def draw_results(image_rgb, results):
    """Return an RGB image with YOLOv7 annotations and a detection dataframe."""
    import pandas as pd
    rendered = np.array(results.render()[0])[:, :, ::-1]  # model render is BGR
    df = results.pandas().xyxy[0].copy()
    if not df.empty:
        keep = ["name", "confidence", "xmin", "ymin", "xmax", "ymax"]
        df = df[keep].rename(columns={
            "name": "Class", "confidence": "Confidence",
            "xmin": "Left", "ymin": "Top", "xmax": "Right", "ymax": "Bottom"
        })
        df["Confidence"] = df["Confidence"].map(lambda x: round(float(x), 3))
    return rendered, df

def metric(label, value):
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">{label}</div>'
        f'<div class="metric-value">{value}</div></div>',
        unsafe_allow_html=True
    )

with st.sidebar:
    st.markdown("## 🎯 YOLOv7 Vision")
    page = st.radio("Navigation", ["Home", "Image Detection", "Video Detection", "Webcam Snapshot", "About Project"])
    st.markdown("---")
    st.markdown("### Model Configuration")
    weights_path = st.text_input("Weights file", value="weights/yolov7.pt", help="Path to your trained or pretrained .pt file.")
    repo_path = st.text_input("YOLOv7 repository folder", value="yolov7", help="Clone the official WongKinYiu/yolov7 repository into this folder.")
    confidence = st.slider("Confidence threshold", 0.10, 0.95, 0.25, 0.05)
    iou = st.slider("NMS IoU threshold", 0.10, 0.90, 0.45, 0.05)
    st.caption("Model loads only when you run detection.")

st.markdown("""
<div class="hero">
  <h1>Real-Time Object Detection Using the YOLOv7 Algorithm</h1>
  <p>Detect, classify, and localize objects in images, videos, and camera snapshots.</p>
</div>
""", unsafe_allow_html=True)

def get_model():
    if not Path(weights_path).is_file():
        st.error(f"Model weights were not found at `{weights_path}`. Add a compatible YOLOv7 .pt file, then try again.")
        st.info("See README.md for setup instructions.")
        st.stop()
    if not Path(repo_path).is_dir():
        st.error(f"YOLOv7 repository folder `{repo_path}` was not found.")
        st.info("Clone the official YOLOv7 repository and install its requirements. See README.md.")
        st.stop()
    try:
        with st.spinner("Loading YOLOv7 model..."):
            return load_model(str(Path(weights_path).resolve()), str(Path(repo_path).resolve()), confidence, iou)
    except Exception as exc:
        st.error("Could not load the model. Check the weights, repository, and dependency versions.")
        st.exception(exc)
        st.stop()

if page == "Home":
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric("Algorithm", "YOLOv7")
    with c2: metric("Detection types", "Image / Video")
    with c3: metric("Input options", "Upload / Camera")
    with c4: metric("Framework", "PyTorch")
    st.markdown('<div class="section-card">', unsafe_allow_html=True)
    st.subheader("Project Overview")
    st.write(
        "This application demonstrates object detection using the YOLOv7 deep-learning model. "
        "The model predicts bounding boxes, object classes, and confidence scores in a single inference pass. "
        "Upload an image or video, or capture a webcam snapshot to see the model output."
    )
    st.subheader("Workflow")
    st.markdown("1. Load YOLOv7 weights.  2. Provide image, video, or camera input.  3. Run inference.  4. Display annotated output and detection details.")
    st.markdown('</div>', unsafe_allow_html=True)
    st.warning("Important: FPS and accuracy are hardware- and model-dependent. The app does not assume a fixed performance result.")

elif page == "Image Detection":
    st.subheader("🖼️ Upload Image for Detection")
    uploaded = st.file_uploader("Choose an image", type=["jpg", "jpeg", "png", "bmp", "webp"])
    if uploaded:
        image = Image.open(uploaded).convert("RGB")
        left, right = st.columns(2)
        with left:
            st.markdown("**Original image**")
            st.image(image, use_container_width=True)
        if st.button("Detect Objects", type="primary"):
            model = get_model()
            start = time.perf_counter()
            results = model(np.array(image))
            elapsed = time.perf_counter() - start
            rendered, df = draw_results(np.array(image), results)
            with right:
                st.markdown("**Detection result**")
                st.image(rendered, use_container_width=True)
            m1, m2 = st.columns(2)
            with m1: metric("Objects detected", len(df))
            with m2: metric("Inference time", f"{elapsed:.3f} s")
            st.markdown("#### Detection Details")
            if df.empty:
                st.info("No objects were detected above the selected confidence threshold.")
            else:
                st.dataframe(df, use_container_width=True, hide_index=True)
                st.download_button("Download detection CSV", df.to_csv(index=False).encode("utf-8"), "detections.csv", "text/csv")

elif page == "Video Detection":
    st.subheader("🎞️ Upload Video for Detection")
    st.caption("The processed video is generated frame-by-frame. Large videos may take some time.")
    uploaded_video = st.file_uploader("Choose a video", type=["mp4", "avi", "mov", "mkv"])
    if uploaded_video and st.button("Process Video", type="primary"):
        model = get_model()
        suffix = Path(uploaded_video.name).suffix or ".mp4"
        with tempfile.TemporaryDirectory() as tmpdir:
            input_path = str(Path(tmpdir) / ("input" + suffix))
            output_path = str(Path(tmpdir) / "yolov7_output.mp4")
            Path(input_path).write_bytes(uploaded_video.getvalue())
            cap = cv2.VideoCapture(input_path)
            if not cap.isOpened():
                st.error("Unable to read this video. Try another file format.")
                st.stop()
            fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
            # MP4V is broadly supported by OpenCV; output may need conversion for some browsers.
            writer = cv2.VideoWriter(output_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height))
            progress = st.progress(0)
            status = st.empty()
            preview = st.empty()
            frame_index = 0
            total_detections = 0
            start = time.perf_counter()
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                results = model(frame_rgb)
                rendered_rgb = np.array(results.render()[0])[:, :, ::-1]
                rendered_bgr = cv2.cvtColor(rendered_rgb, cv2.COLOR_RGB2BGR)
                writer.write(rendered_bgr)
                try:
                    total_detections += len(results.pandas().xyxy[0])
                except Exception:
                    pass
                frame_index += 1
                if frame_index % 5 == 0 or (total and frame_index == total):
                    preview.image(rendered_rgb, caption=f"Processed frame {frame_index}", use_container_width=True)
                    progress.progress(min(frame_index / total, 1.0) if total else 0.0)
                    status.write(f"Processed {frame_index}" + (f" / {total} frames" if total else " frames"))
            cap.release()
            writer.release()
            elapsed = time.perf_counter() - start
            if Path(output_path).exists() and Path(output_path).stat().st_size > 0:
                st.success(f"Finished processing {frame_index} frames in {elapsed:.1f} seconds.")
                st.write(f"Total detections across frames: {total_detections}")
                st.video(Path(output_path).read_bytes())
                st.download_button("Download processed video", Path(output_path).read_bytes(), "yolov7_output.mp4", "video/mp4")
            else:
                st.error("The processed video could not be created.")

elif page == "Webcam Snapshot":
    st.subheader("📷 Camera Detection")
    st.caption("Streamlit's built-in camera input captures a snapshot, rather than providing continuous live video.")
    camera_image = st.camera_input("Take a picture")
    if camera_image and st.button("Detect in Snapshot", type="primary"):
        model = get_model()
        image = Image.open(camera_image).convert("RGB")
        results = model(np.array(image))
        rendered, df = draw_results(np.array(image), results)
        st.image(rendered, caption="YOLOv7 detection result", use_container_width=True)
        st.metric("Objects detected", len(df))
        if df.empty:
            st.info("No objects detected.")
        else:
            st.dataframe(df, use_container_width=True, hide_index=True)

elif page == "About Project":
    st.subheader("About the Project")
    st.write("**Title:** Real-Time Object Detection Using the YOLOv7 Algorithm")
    st.write("**Objective:** Build an interactive application that detects and labels objects from image, video, and camera snapshot inputs.")
    st.write("**Core technologies:** Python, Streamlit, OpenCV, PyTorch, YOLOv7.")
    st.write("**Evaluation metrics to record:** precision, recall, mAP, inference latency, and FPS. These should be measured on the actual dataset and hardware.")
    st.markdown("#### Main modules")
    st.markdown("- Input module: image/video upload and camera snapshot.\n- Detection module: YOLOv7 model inference.\n- Visualization module: bounding boxes, labels, confidence scores.\n- Results module: detection table and downloadable CSV or processed video.")
    st.markdown("#### Limitations")
    st.markdown("- Requires a compatible YOLOv7 repository, weights file, and Python dependencies.\n- Streamlit camera input is snapshot-based; continuous webcam streaming needs an additional streaming component.\n- Results depend on the training data, model weights, lighting, object size, and available compute.")

st.markdown("---")
st.caption("Academic demonstration app • Real-Time Object Detection Using YOLOv7")
